package ua.epam;

/**
 * Created by Dmytro_Rybin on 9/15/2016.
 */
public class Controller {
    private Model model;
    private View view;
    private int count = 0;


    public Controller(Model model, View view) {
        this.model = model;
        this.view = view;
    }

    public void startGame() {
        if(!model.isStarted()) {
            model.generateRandomNumber();
        }
    }

    public void gameFlow() {
        while(true) {
            count++;
            view.printMessage("enter number from " + model.getLow() + " to " + model.getHigh() + ":");

            try {
                //     number = scan.nextInt();
                generatedNumber = Integer.parseInt(scan.nextLine());

                if (model.checkBorders(generatedNumber) == 1) {
                    view.printMessage("You exceed higher border ");
                    continue;
                }
                else if (model.checkBorders(generatedNumber) == -1) {
                    view.printMessage("You exceed lower border ");
                    continue;
                }

                code = model.compare(generatedNumber);
                if (code == 10){
                    view.printMessage("You won!!! Random was " + generatedNumber + " . Number of attempts: " + count);
                    break;
                }
                else {
                    if (code == -1){
                        view.printMessage("Your number is lower than random");
                    }
                    if (code == 1){
                        view.printMessage("Your number is higher than random");
                    }
                }
            } catch (Exception e) {
                e.getMessage();
                System.out.println("Wrong input");
                continue;
                //   main(args);
            }
        }
    }
}
