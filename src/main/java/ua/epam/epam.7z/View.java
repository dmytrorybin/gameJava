package ua.epam;

/**
 * Created by Dmytro_Rybin on 9/15/2016.
 */
public class View {
    public void printMessage(String st) {
        System.out.println(st);
    }
}
