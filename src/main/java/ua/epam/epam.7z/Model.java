package ua.epam;

import java.util.InputMismatchException;

/**
 * Created by Dmytro_Rybin on 9/15/2016.
 */
public class Model {
    public final int RAND_MIN = 0;
    public final int RAND_MAX = 100;
    private int low;
    private int high;
    private boolean isStarted = false;
    private int generatedNumber;

    public int generateRandomNumber() {
        int generatedNumber = (int)(Math.random() * (RAND_MAX - RAND_MIN)) + RAND_MIN;
        if (generatedNumber == 0)
            generatedNumber += 1;
        return generatedNumber;
    }

    public int generateRandomNumber(int min, int max) {
        int generatedNumber = (int)(Math.random() * (max - min)) + min;
        if (generatedNumber == 0)
            generatedNumber += 1;
        return generatedNumber;
    }

    public int compare(int number) throws InputMismatchException {
        if (generatedNumber == number) {
            return 10;
        }
        else if (number > generatedNumber) {
            high = number;
            return 1;
        }
        else if (number < generatedNumber) {
            low = number;
            return -1;
        }
        return 0;
    }

    public  int checkBorders(int number) {
        if (number >= high) {
            return 1;
        }
        else if (number <= low) {
            return -1;
        }
        return 0;
    }

    public int getLow() { return low; }

    public int getHigh() {
        return high;
    }

    public boolean isStarted() {
        return isStarted;
    }

    public void setStarted(boolean started) {
        isStarted = started;
    }
}
